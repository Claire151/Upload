//
//  Friend.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/28.
//

import Foundation

struct Friend: Codable {
    let name: String
    let status: Int
    let isTop: String
    let fid: String
    let updateDate: String
        
    var dateUpdated: Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        return formatter.date(from: updateDate)
    }
}

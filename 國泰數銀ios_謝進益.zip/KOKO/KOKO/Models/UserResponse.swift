//
//  UserResponse.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/30.
//

import Foundation

struct UserResponse: Codable {
    let response: [User]
}

//
//  User.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/28.
//

import Foundation

struct User: Codable {
    let name: String
    let kokoid: String
}

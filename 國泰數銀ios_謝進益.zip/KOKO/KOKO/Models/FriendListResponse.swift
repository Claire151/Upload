//
//  FriendListResponse.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/29.
//

import Foundation

struct FriendListResponse: Codable {
    let response: [Friend]
}

//
//  TestValidator.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/8/1.
//

import Foundation

// MARK: - Class Definition
class TestValidator {
    
    // MARK: - Public Methods
    static func runBasicTests() {
        print("1. 開始執行基本測試...")
        
        testDisplayStates()
        
        testSearchFilter()
        
        testInvitationExpansion()
        
        print("4. 基本測試完成")
    }
    
    // MARK: - Private Test Methods
    private static func testDisplayStates() {
        print("1.1 測試顯示狀態...")
        
        let viewModel = FriendsListViewModel()
        
        viewModel.friends = []
        viewModel.invitations = []
        assert(viewModel.displayState == .noFriends, "無好友狀態測試失敗")
        print("1.1.1 無好友狀態測試通過")
        
        let friend = Friend(name: "Test Friend", status: 1, isTop: "0", fid: "1", updateDate: "2025/01/01")
        viewModel.friends = [friend]
        viewModel.invitations = []
        assert(viewModel.displayState == .friendsOnly, "只有好友狀態測試失敗")
        print("1.1.2 只有好友狀態測試通過")
        
        let invitation = Friend(name: "Test Invitation", status: 2, isTop: "0", fid: "2", updateDate: "2025/01/01")
        viewModel.invitations = [invitation]
        assert(viewModel.displayState == .friendsWithInvitations, "好友含邀請狀態測試失敗")
        print("1.1.3 好友含邀請狀態測試通過")
    }
    
    private static func testSearchFilter() {
        print("2.1 測試搜尋過濾...")
        
        let viewModel = FriendsListViewModel()
        let friend1 = Friend(name: "Alice", status: 1, isTop: "0", fid: "1", updateDate: "2025/01/01")
        let friend2 = Friend(name: "Bob", status: 1, isTop: "0", fid: "2", updateDate: "2025/01/01")
        
        viewModel.setTestData(friends: [friend1, friend2], invitations: [])
        
        viewModel.searchText = ""
        assert(viewModel.friends.count == 2, "空搜尋測試失敗")
        print("2.1.1 空搜尋測試通過")
        
        viewModel.searchText = "Alice"
        assert(viewModel.friends.count == 1, "搜尋文字測試失敗")
        assert(viewModel.friends.first?.name == "Alice", "搜尋結果測試失敗")
        print("2.1.2 搜尋文字測試通過")
    }
    
    private static func testInvitationExpansion() {
        print("3.1 測試邀請展開...")
        
        let viewModel = FriendsListViewModel()
        
        assert(!viewModel.isInvitationListExpanded, "初始展開狀態測試失敗")
        print("3.1.1 初始展開狀態測試通過")
        
        viewModel.toggleInvitationListExpansion()
        assert(viewModel.isInvitationListExpanded, "展開狀態切換測試失敗")
        print("3.1.2 展開狀態切換測試通過")
        
        viewModel.toggleInvitationListExpansion()
        assert(!viewModel.isInvitationListExpanded, "再次切換測試失敗")
        print("3.1.3 再次切換測試通過")
    }
}

// MARK: - Test Utilities
func assert(_ condition: Bool, _ message: String) {
    if !condition {
        print("❌ 測試失敗: \(message)") 
    }
}

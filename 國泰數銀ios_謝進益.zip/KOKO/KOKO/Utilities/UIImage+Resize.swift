//
//  UIImage+Resize.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/8/1.
//

import UIKit

// MARK: - UIImage Extension
extension UIImage {
    func resized(to size: CGSize) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { context in
            self.draw(in: CGRect(origin: .zero, size: size))
        }
    }
}

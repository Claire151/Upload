//
//  APIService.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/29.
//

import Foundation

// MARK: - Class Definition
class APIService {
    
    static let shared = APIService()
    
    private init() {}

    // MARK: - API Calls
    func fetchUser(completion: @escaping(Result<UserResponse, APIError>) -> Void) {
        fetchData(urlString: "https://dimanyen.github.io/man.json", completion: completion)
    }
    
    func fetchFriendList1(completion: @escaping(Result<FriendListResponse, APIError>) -> Void) {
        fetchData(urlString: "https://dimanyen.github.io/friend1.json", completion: completion)
    }
    
    func fetchFriendList2(completion: @escaping(Result<FriendListResponse, APIError>) -> Void) {
        fetchData(urlString: "https://dimanyen.github.io/friend2.json", completion: completion)
    }
    
    func fetchFriendListWithInvitation(completion: @escaping(Result<FriendListResponse, APIError>) -> Void) {
        fetchData(urlString: "https://dimanyen.github.io/friend3.json", completion: completion)
    }
    
    func fetchEmptyFriendList(completion: @escaping(Result<FriendListResponse, APIError>) -> Void) {
        fetchData(urlString: "https://dimanyen.github.io/friend4.json", completion: completion)
    }
    
    // MARK: - Generic Fetch Method
    func fetchData<T: Decodable>(urlString: String, completion: @escaping(Result<T, APIError>) -> Void) {
        guard let url = URL(string: urlString) else {
            completion(.failure(.invalidURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(.networkError(error)))
                    return
                }
                
                guard let data = data else {
                    completion(.failure(.noData))
                    return
                }
                
                do {
                    let decodedData = try JSONDecoder().decode(T.self, from: data)
                    completion(.success(decodedData))
                } catch {
                    completion(.failure(.decodingError(error)))
                }
            }
        }.resume()
    }
}

// MARK: - APIError Enum
enum APIError: Error, LocalizedError {
    case invalidURL
    case noData
    case decodingError(Error)
    case networkError(Error)
    case unknownError
    
    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return NSLocalizedString("網址無效，請檢查。", comment: "Invalid URL")
        case .noData:
            return NSLocalizedString("伺服器未返回資料。", comment: "No data from server")
        case .decodingError(let error):
            return NSLocalizedString("資料解析失敗:\(error.localizedDescription)。", comment: "Decoding failed")
        case .networkError(let error):
            return NSLocalizedString("網路請求失敗:\(error.localizedDescription)。", comment: "Network request failed")
        case .unknownError:
            return NSLocalizedString("發生未知錯誤。", comment: "Unknown error occurred")
        }
    }
}

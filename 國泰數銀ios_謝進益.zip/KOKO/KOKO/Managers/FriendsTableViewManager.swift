//
//  FriendsTableViewManager.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/8/1.
//

import UIKit

// MARK: - Protocols
protocol FriendsTableViewManagerDelegate: AnyObject {
    func didSelectFriend(at indexPath: IndexPath)
}

// MARK: - Class Definition
class FriendsTableViewManager: NSObject, UITableViewDataSource, UITableViewDelegate {
    
    // MARK: - Properties
    weak var viewModel: FriendsListViewModel?
    weak var delegate: FriendsTableViewManagerDelegate?
    
    // MARK: - UITableViewDataSource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel?.friends.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let viewModel = viewModel else { return UITableViewCell() }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "FriendCell", for: indexPath) as! FriendCell
        let friend = viewModel.friends[indexPath.row]
        cell.configure(with: friend)
        return cell
    }
    
    // MARK: - UITableViewDelegate Methods
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        delegate?.didSelectFriend(at: indexPath)
    }
}

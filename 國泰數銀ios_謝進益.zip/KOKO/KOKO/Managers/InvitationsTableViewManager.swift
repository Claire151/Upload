//
//  InvitationsTableViewManager.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/8/1.
//

import UIKit

// MARK: - Protocols
protocol InvitationsTableViewManagerDelegate: AnyObject {
    func didToggleInvitationExpansion()
}

// MARK: - Class Definition
class InvitationsTableViewManager: NSObject, UITableViewDataSource, UITableViewDelegate {
    
    // MARK: - Properties
    weak var viewModel: FriendsListViewModel?
    weak var delegate: InvitationsTableViewManagerDelegate?
    
    // MARK: - UITableViewDataSource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let viewModel = viewModel else { return 0 }
        
        guard viewModel.displayState == .friendsWithInvitations && !viewModel.invitations.isEmpty else {
            return 0
        }
        
        return viewModel.isInvitationListExpanded ? viewModel.invitations.count : (viewModel.invitations.count > 0 ? 1 : 0)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let viewModel = viewModel else { return UITableViewCell() }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "InvitationCell", for: indexPath) as! InvitationCell
        let invitation = viewModel.invitations[indexPath.row]
        cell.configure(with: invitation)
        
        return cell
    }
    
    // MARK: - UITableViewDelegate Methods
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if viewModel?.displayState == .friendsWithInvitations && !(viewModel?.invitations.isEmpty ?? true) {
            viewModel?.toggleInvitationListExpansion()
            delegate?.didToggleInvitationExpansion()
        }
    }
}

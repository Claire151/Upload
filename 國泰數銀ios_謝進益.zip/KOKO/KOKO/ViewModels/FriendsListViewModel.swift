//
//  FriendsListViewModel.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/29.
//

import Foundation

// MARK: - Class Definition
class FriendsListViewModel {
    
    // MARK: - Properties
    var isLoading: Bool = false {
        didSet {
            onLoadingStateChange?(isLoading)
        }
    }
    
    var errorMessage: String? {
        didSet {
            if errorMessage != nil {
                onErrorOccurred?(errorMessage)
            }
        }
    }
    
    var userName: String? {
        didSet {
            onUserUpdate?()
        }
    }
    
    var kokoID: String? {
        didSet {
            onUserUpdate?()
        }
    }
    
    internal var allFriends: [Friend] = [] {
        didSet {
            applySearchFilter()
        }
    }
    
    internal var allInvitations: [Friend] = [] {
        didSet {
            applySearchFilter()
        }
    }
    
    var friends: [Friend] = [] {
        didSet {
            onFriendsUpdate?()
            updateDisplayState()
        }
    }
    
    var invitations: [Friend] = [] {
        didSet {
            onInvitationsUpdate?()
            updateDisplayState()
        }
    }

    var displayState: FriendListDisplayState = .noFriends {
        didSet {
            onDisplayStateChange?(displayState)
        }
    }
    
    var isInvitationListExpanded: Bool = false {
        didSet {
            onInvitationsExpansionChange?(isInvitationListExpanded)
        }
    }
    
    var searchText: String = "" {
        didSet {
            if oldValue != searchText {
                applySearchFilter()
            }
        }
    }
    
    // MARK: - Callbacks
    var onLoadingStateChange: ((Bool) -> Void)?
    var onErrorOccurred: ((String?) -> Void)?
    var onUserUpdate: (() -> Void)?
    var onFriendsUpdate: (() -> Void)?
    var onInvitationsUpdate: (() -> Void)?
    var onDisplayStateChange: ((FriendListDisplayState) -> Void)?
    var onInvitationsExpansionChange: ((Bool) -> Void)?
    
    // MARK: - Public Methods
    func loadData(scenario: Scenario) {
        isLoading = true
        errorMessage = nil
        
        fetchUserData { [weak self] in
            guard let self = self else { return }
            
            if self.userName != nil && self.kokoID != nil {
                switch scenario {
                case .noFriends:
                    self.fetchEmptyFriendListData()
                case .friendsOnly:
                    self.fetchFriendListOnlyData()
                case .friendsWithInvitations:
                    self.fetchFriendListWithInvitationData()
                }
            } else {
                self.isLoading = false
            }
        }
    }
    
    func toggleInvitationListExpansion() {
        isInvitationListExpanded.toggle()
    }
    
    // MARK: - Private API Calls
    private func fetchUserData(completion: @escaping () -> Void) {
        APIService.shared.fetchUser { [weak self] result in
            guard let self = self else { return }
            DispatchQueue.main.async {
                switch result {
                case .success(let userResponse):
                    if let user = userResponse.response.first {
                        self.userName = user.name
                        self.kokoID = user.kokoid
                    } else {
                        self.errorMessage = "Failed to load user data: Response array is empty."
                    }
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                }
                completion()
            }
        }
    }
    
    private func fetchEmptyFriendListData() {
        APIService.shared.fetchEmptyFriendList { [weak self] result in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let response):
                    self.allFriends = response.response.filter { $0.status != 2 }
                    self.allInvitations = response.response.filter { $0.status == 2 }
                    self.updateDisplayState()
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                    self.allFriends = []
                    self.allInvitations = []
                    self.updateDisplayState()
                }
            }
        }
    }
    
    private func fetchFriendListOnlyData() {
        let dispatchGroup = DispatchGroup()
        var friendsFromAPI1: [Friend] = []
        var friendsFromAPI2: [Friend] = []
        var encounteredError: [APIError] = []
        
        dispatchGroup.enter()
        APIService.shared.fetchFriendList1 { result in
            defer { dispatchGroup.leave() }
            switch result {
            case .success(let response):
                friendsFromAPI1 = response.response
            case .failure(let error):
                encounteredError.append(error)
            }
        }
        
        dispatchGroup.enter()
        APIService.shared.fetchFriendList2 { result in
            defer { dispatchGroup.leave() }
            switch result {
            case .success(let response):
                friendsFromAPI2 = response.response
            case .failure(let error):
                encounteredError.append(error)
            }
        }
        
        dispatchGroup.notify(queue: .main) { [weak self] in
            guard let self = self else { return }
            self.isLoading = false
            
            if !encounteredError.isEmpty {
                self.errorMessage = encounteredError.map { $0.localizedDescription }.joined(separator: "\n")
                self.allFriends = []
                self.allInvitations = []
                self.updateDisplayState()
                return
            }
            
            var mergedFriendsDict: [String: Friend] = [:]
            (friendsFromAPI1 + friendsFromAPI2).forEach { friend in
                if let existingFriend = mergedFriendsDict[friend.name] {
                    if let existingDate = existingFriend.dateUpdated,
                       let newDate = friend.dateUpdated,
                       newDate > existingDate {
                        mergedFriendsDict[friend.name] = friend
                    }
                } else {
                    mergedFriendsDict[friend.name] = friend
                }
            }
            
            self.allFriends = mergedFriendsDict.values.filter { $0.status != 2 }.sorted {
                $0.name < $1.name
            }
            self.allInvitations = []
            self.updateDisplayState()
        }
    }
    
    private func fetchFriendListWithInvitationData() {
        APIService.shared.fetchFriendListWithInvitation { [weak self] result in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let response):
                    self.allInvitations = response.response.filter { $0.status == 2 }
                    self.allFriends = response.response.filter { $0.status != 2 }
                    self.allFriends.sort { $0.name < $1.name }
                    self.allInvitations.sort { $0.name < $1.name }
                    self.updateDisplayState()
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                    self.allFriends = []
                    self.allInvitations = []
                    self.updateDisplayState()
                }
            }
        }
    }
    
    // MARK: - Private Data Processing
    private func applySearchFilter() {
    
        if searchText.isEmpty {
            friends = allFriends
            invitations = allInvitations
        } else {
            friends = allFriends.filter { friend in
                friend.name.localizedCaseInsensitiveContains(searchText)
            }
            invitations = allInvitations.filter { invitation in
                invitation.name.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    private func updateDisplayState() {
        if searchText.isEmpty {
            if friends.isEmpty && invitations.isEmpty {
                displayState = .noFriends
            } else if !friends.isEmpty && invitations.isEmpty {
                displayState = .friendsOnly
            } else {
                displayState = .friendsWithInvitations
            }
        }
    }
    
    // MARK: - Test Helpers
    func setTestData(friends: [Friend], invitations: [Friend]) {
        self.allFriends = friends
        self.allInvitations = invitations
    }
    
    func validateDisplayState() -> Bool {
        switch displayState {
        case .noFriends:
            return friends.isEmpty && invitations.isEmpty
        case .friendsOnly:
            return !friends.isEmpty && invitations.isEmpty
        case .friendsWithInvitations:
            return !friends.isEmpty || !invitations.isEmpty
        }
    }
    
    func validateSearchFilter(searchText: String) -> Bool {
        if searchText.isEmpty {
            return friends.count == allFriends.count && invitations.count == allInvitations.count
        } else {
            let expectedFriends = allFriends.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
            let expectedInvitations = allInvitations.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
            return friends.count == expectedFriends.count && invitations.count == expectedInvitations.count
        }
    }
    
    func validateInvitationExpansion() -> Bool {
        return true
    }
}

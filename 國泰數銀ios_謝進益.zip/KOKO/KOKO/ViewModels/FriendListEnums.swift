//
//  FriendListEnums.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/29.
//

import Foundation

// MARK: - FriendListDisplayState Enum
enum FriendListDisplayState {
    case noFriends
    case friendsOnly
    case friendsWithInvitations
}

// MARK: - Scenario Enum
enum Scenario: CaseIterable {
    case noFriends
    case friendsOnly
    case friendsWithInvitations
}

//
//  NoFriendsView.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/8/1.
//

import UIKit

// MARK: - Class Definition
class NoFriendsView: UIView {
    
    // MARK: - IBOutlets
    @IBOutlet weak var handshakeImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var actionButton: UIButton!
    @IBOutlet weak var helpFriendToFindYou: UILabel!
    @IBOutlet weak var setKokoID: UILabel!
    
    // MARK: - Initialization
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    // MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()
        
        actionButton.layer.cornerRadius = 20
        actionButton.clipsToBounds = true
        
        addGradientLayer()
        
        titleLabel.text = "就從加好友開始吧 :)"
        
        descriptionLabel.text = "與好友們一起用 KOKO 聊起來!\n還能互動收付款、發紅包喔 :)"
        actionButton.setTitle("加好友", for: .normal)
        actionButton.semanticContentAttribute = .forceRightToLeft
        actionButton.configuration?.imagePadding = 8.0
        
        helpFriendToFindYou.text = "幫助好友更快找到你？"
        setKokoID.text = "設定 KOKO ID"
        
        let attributeString = NSMutableAttributedString(string: setKokoID.text ?? "")
        attributeString.addAttribute(NSAttributedString.Key.underlineStyle,
                                     value: NSUnderlineStyle.single.rawValue,
                                     range: NSRange(location: 0, length: attributeString.length))
        setKokoID.attributedText = attributeString
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(setKokoIDTapped))
        setKokoID.isUserInteractionEnabled = true
        setKokoID.addGestureRecognizer(tapGesture)
    }
    
    // MARK: - Public Methods
    static func instantiate() -> NoFriendsView {
        let view = UINib(nibName: "NoFriendsView", bundle: nil).instantiate(withOwner: nil, options: nil).first as! NoFriendsView
        return view
    }
    
    // MARK: - Actions
    @IBAction func actionButtonTapped(_ sender: UIButton) {
        // TODO: 處理加入好友功能
    }
    
    @objc private func setKokoIDTapped() {
        // TODO: 處理設定 KOKO ID 功能
    }
    
    // MARK: - Private Helpers
    private func addGradientLayer() {
        let gradientLayer = CAGradientLayer()
        
        let startColor = UIColor(red: 86/255, green: 179/255, blue: 11/255, alpha: 1.0).cgColor
        let endColor = UIColor(red: 166/255, green: 204/255, blue: 66/255, alpha: 1.0).cgColor
        
        gradientLayer.colors = [startColor, endColor]
        
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        
        gradientLayer.frame = actionButton.bounds
        
        actionButton.layer.insertSublayer(gradientLayer, at: 0)
    }
}

//
//  FriendsListViewController.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/30.
//

import UIKit

// MARK: - Class Definition
class FriendsListViewController: UIViewController, UISearchBarDelegate, FriendsTableViewManagerDelegate, InvitationsTableViewManagerDelegate {
    
    // MARK: - IBOutlets
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var kokoIDLabel: UILabel!
    @IBOutlet weak var userAvatarImageView: UIImageView!
    
    @IBOutlet weak var invitationsTableView: UITableView!
    @IBOutlet weak var invitationsTableViewHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var tabContainerStackView: UIStackView!
    @IBOutlet weak var friendsTabButton: UIButton!
    @IBOutlet weak var chatTabButton: UIButton!
    @IBOutlet weak var friendsIndicatorView: UIView!
    @IBOutlet weak var chatIndicatorView: UIView!
    @IBOutlet weak var friendsNotificationLabel: UILabel!
    @IBOutlet weak var chatNotificationLabel: UILabel!
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var icBtnAddFriendsImage: UIImageView!
    
    @IBOutlet weak var friendsTableView: UITableView!
    
    @IBOutlet weak var noFriendsStateView: UIView!
    
    // MARK: - Properties
    var viewModel: FriendsListViewModel?
    
    private var friendsTableViewManager: FriendsTableViewManager!
    private var invitationsTableViewManager: InvitationsTableViewManager!
    
    private var currentSelectedTab: Int = 0 { // 0: 好友, 1: 聊天
        didSet {
            updateUIForTabChange()
        }
    }
    
    private var refreshControl: UIRefreshControl!
    private var currentScenario: Scenario = .noFriends
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        friendsTableViewManager = FriendsTableViewManager()
        friendsTableViewManager.viewModel = viewModel
        friendsTableViewManager.delegate = self
        
        invitationsTableViewManager = InvitationsTableViewManager()
        invitationsTableViewManager.viewModel = viewModel
        invitationsTableViewManager.delegate = self
        
        friendsTableView.dataSource = friendsTableViewManager
        friendsTableView.delegate = friendsTableViewManager
        invitationsTableView.dataSource = invitationsTableViewManager
        invitationsTableView.delegate = invitationsTableViewManager
        
        friendsTableView.register(UINib(nibName: "FriendCell", bundle: nil), forCellReuseIdentifier: "FriendCell")
        invitationsTableView.register(UINib(nibName: "InvitationCell", bundle: nil), forCellReuseIdentifier: "InvitationCell")
        
        invitationsTableView.rowHeight = UITableView.automaticDimension
        invitationsTableView.estimatedRowHeight = 100
        
        invitationsTableView.separatorStyle = .none
        
        invitationsTableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: invitationsTableView.bounds.size.width, height: CGFloat.leastNormalMagnitude))
        invitationsTableView.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: invitationsTableView.bounds.size.width, height: CGFloat.leastNormalMagnitude))
        
        searchBar.delegate = self
        
        friendsTabButton.addTarget(self, action: #selector(tabButtonTapped(_:)), for: .touchUpInside)
        chatTabButton.addTarget(self, action: #selector(tabButtonTapped(_:)), for: .touchUpInside)
        
        setupTabButtonConfigurations()
        setupNotificationBadges()
        setupInvitationsUI()
        setupPullToRefresh()
        
        setupBindings()
        
        updateUserProfileUI()
        updateUIForTabChange()
        
        searchBar.placeholder = "想轉一筆錢給誰呢？"
        
        viewModel?.loadData(scenario: currentScenario)
    }
    
    // MARK: - Public Methods
    func setCurrentScenario(_ scenario: Scenario) {
        currentScenario = scenario
        viewModel?.loadData(scenario: currentScenario)
    }
    
    // MARK: - Private Setup
    private func setupPullToRefresh() {
        refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        refreshControl.attributedTitle = NSAttributedString(string: "下拉重新整理")
        friendsTableView.refreshControl = refreshControl
    }
    
    private func setupNotificationBadges() {
        friendsNotificationLabel.layer.cornerRadius = 9
        friendsNotificationLabel.layer.masksToBounds = true
        friendsNotificationLabel.textColor = .white
        friendsNotificationLabel.backgroundColor = UIColor(red: 236/255, green: 0/255, blue: 140/255, alpha: 1.0)
        
        chatNotificationLabel.layer.cornerRadius = 9
        chatNotificationLabel.layer.masksToBounds = true
        chatNotificationLabel.textColor = .white
        chatNotificationLabel.backgroundColor = UIColor(red: 236/255, green: 0/255, blue: 140/255, alpha: 1.0)
    }
    
    private func setupInvitationsUI() {
        invitationsTableView.backgroundColor = .clear
        invitationsTableView.layer.masksToBounds = false
        invitationsTableView.clipsToBounds = false
    }
    
    private func setupTabButtonConfigurations() {
        var friendsConfig = UIButton.Configuration.plain()
        friendsConfig.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0)
        friendsConfig.titlePadding = 0
        friendsTabButton.configuration = friendsConfig
        
        var chatConfig = UIButton.Configuration.plain()
        chatConfig.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0)
        chatConfig.titlePadding = 0
        chatTabButton.configuration = chatConfig
    }
    
    private func setupBindings() {
        guard let viewModel = viewModel else { return }
        
        viewModel.onDisplayStateChange = { [weak self] state in
            DispatchQueue.main.async {
                self?.updateDisplayStateUI()
            }
        }
        
        viewModel.onFriendsUpdate = { [weak self] in
            DispatchQueue.main.async {
                self?.friendsTableView.reloadData()
            }
        }
        
        viewModel.onInvitationsUpdate = { [weak self] in
            DispatchQueue.main.async {
                self?.viewModel?.isInvitationListExpanded = false
                self?.updateInvitationsUI()
                self?.updateFriendsNotificationBadge()
            }
        }
        
        viewModel.onUserUpdate = { [weak self] in
            DispatchQueue.main.async {
                self?.updateUserProfileUI()
            }
        }
        
        viewModel.onLoadingStateChange = { [weak self] isLoading in
            DispatchQueue.main.async {
                //TODO: 處理載入狀態變化，顯示/隱藏活動指示器
                self = self
            }
        }
        
        viewModel.onErrorOccurred = { [weak self] errorMessage in
            DispatchQueue.main.async {
                if let message = errorMessage {
                    // TODO: 顯示警報或其他錯誤回饋
                    print(message)
                    self = self
                }
            }
        }
        
        viewModel.onInvitationsExpansionChange = { [weak self] isExpanded in
            DispatchQueue.main.async {
                self?.updateInvitationsUI(animated: true)
            }
        }
    }
    
    // MARK: - Private UI Updates
    private func updateUserProfileUI() {
        guard let viewModel = viewModel else { return }
        userNameLabel.text = viewModel.userName
        if let kokoID = viewModel.kokoID, !kokoID.isEmpty {
            kokoIDLabel.text = "KOKO ID : \(kokoID)"
        } else {
            kokoIDLabel.text = "設定 KOKO ID"
        }
        userAvatarImageView.image = UIImage(named: "imgUserInfoDefaultAvatar")
    }
    
    private func updateUIForTabChange() {
        updateTabButtonsUI()
        
        let isFriendsTabSelected = (currentSelectedTab == 0)
        
        searchBar.isHidden = !isFriendsTabSelected
        icBtnAddFriendsImage.isHidden = !isFriendsTabSelected
        
        if isFriendsTabSelected {
            updateDisplayStateUI()
        } else {
            friendsTableView.isHidden = true
            noFriendsStateView.isHidden = true
            invitationsTableView.isHidden = true
            
            UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
            }
        }
    }
    
    private func updateTabButtonsUI() {
        friendsTabButton.setTitleColor(currentSelectedTab == 0 ? .black : .lightGray, for: .normal)
        chatTabButton.setTitleColor(currentSelectedTab == 1 ? .black : .lightGray, for: .normal)
        
        friendsIndicatorView.isHidden = (currentSelectedTab != 0)
        chatIndicatorView.isHidden = (currentSelectedTab != 1)
    }
    
    private func updateFriendsNotificationBadge() {
        guard let viewModel = viewModel else { return }
            
        let friendsNotificationCount = viewModel.invitations.count
        if friendsNotificationCount > 0 {
            friendsNotificationLabel.text = "\(friendsNotificationCount)"
            friendsNotificationLabel.isHidden = false
        } else {
            friendsNotificationLabel.isHidden = true
        }
            
        if viewModel.displayState == .noFriends {
            chatNotificationLabel.text = ""
            chatNotificationLabel.isHidden = true
        } else {
            chatNotificationLabel.text = "99+"
            chatNotificationLabel.isHidden = false
        }
    }
    
    private func updateDisplayStateUI() {
        guard let viewModel = viewModel else { return }
        guard currentSelectedTab == 0 else { return }
        
        noFriendsStateView.isHidden = (viewModel.displayState != .noFriends)
        friendsTableView.isHidden = (viewModel.displayState == .noFriends)
        
        updateInvitationsUI(animated: true)
        friendsTableView.reloadData()
        
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    
    private func updateInvitationsUI(animated: Bool = false) {
        invitationsTableView.reloadData()
        
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }

            var newHeight: CGFloat = 0
            guard let viewModel = self.viewModel else {
                self.invitationsTableViewHeightConstraint.constant = newHeight
                self.invitationsTableView.isHidden = true
                return
            }
            
            self.invitationsTableView.layoutIfNeeded()

            if viewModel.displayState == .friendsWithInvitations && !viewModel.invitations.isEmpty && self.currentSelectedTab == 0 {
                
                let actualContentHeight = self.invitationsTableView.contentSize.height
                
                let singleCardEstimatedDisplayHeight: CGFloat = 110.0
                let maxInvitationsTableHeight = singleCardEstimatedDisplayHeight * 3.0
                
                newHeight = min(actualContentHeight, maxInvitationsTableHeight)
                
                if !viewModel.isInvitationListExpanded {
                    newHeight = singleCardEstimatedDisplayHeight
                }
            } else {
                newHeight = 0
            }
            
            self.invitationsTableViewHeightConstraint.constant = newHeight
            self.invitationsTableView.isHidden = (newHeight == 0 || self.currentSelectedTab != 0)
            
            if animated {
                UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut) {
                    self.view.layoutIfNeeded()
                }
            }
        }
    }
    
    // MARK: - Actions
    @objc private func refreshData() {
        guard let viewModel = viewModel else {
            refreshControl.endRefreshing()
            return
        }
        
        viewModel.loadData(scenario: currentScenario)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            self?.refreshControl.endRefreshing()
        }
    }
    
    @objc private func tabButtonTapped(_ sender: UIButton) {
        if sender == friendsTabButton {
            currentSelectedTab = 0
        } else if sender == chatTabButton {
            currentSelectedTab = 1
        }
    }
    
    // MARK: - Delegate Methods
    // MARK: FriendsTableViewManagerDelegate
    func didSelectFriend(at indexPath: IndexPath) {
        // TODO: 處理好友清單點擊，導覽至聊天頁面
    }
    
    // MARK: InvitationsTableViewManagerDelegate
    func didToggleInvitationExpansion() {
        updateInvitationsUI(animated: true)
    }
    
    // MARK: UISearchBarDelegate
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // 呈現後，搜尋邏輯由 SearchViewController 處理
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        presentSearchViewController()
    }
    
    // MARK: - Navigation
    private func presentSearchViewController() {
        let searchVC = SearchViewController()
        searchVC.viewModel = viewModel
        
        let navController = UINavigationController(rootViewController: searchVC)
        
        navController.modalPresentationStyle = .fullScreen
        navController.modalTransitionStyle = .crossDissolve
        
        present(navController, animated: true, completion: nil)
    }
}

//
//  FriendCell.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/30.
//

import UIKit

// MARK: - Class Definition
class FriendCell: UITableViewCell {

    // MARK: - IBOutlets
    @IBOutlet weak var starImageView: UIImageView!
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var transferButton: UIButton!
    @IBOutlet weak var statusButton: UIButton!
    
    // MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()
        
        avatarImageView.layer.cornerRadius = avatarImageView.frame.width / 2
        avatarImageView.clipsToBounds = true
        
        transferButton.layer.borderWidth = 1
        transferButton.layer.borderColor = CGColor(red: 236/255, green: 0/255, blue: 140/255, alpha: 1.0)
        transferButton.setTitleColor(UIColor.orange, for: .normal)
        transferButton.backgroundColor = .clear
        transferButton.configuration?.titlePadding = 0
        transferButton.titleLabel?.adjustsFontSizeToFitWidth = true
        
        statusButton.layer.borderWidth = 1
        statusButton.layer.borderColor = UIColor.lightGray.cgColor
        statusButton.setTitleColor(UIColor.lightGray, for: .normal)
        statusButton.backgroundColor = .clear
        statusButton.configuration?.titlePadding = 0
        statusButton.titleLabel?.adjustsFontSizeToFitWidth = true
        statusButton.isEnabled = false
    }

    // MARK: - Configuration
    func configure(with friend: Friend) {
        starImageView.isHidden = !(friend.isTop == "1")
        
        avatarImageView?.image = UIImage(named: "imgFriendsListDefaultAvatar")
        
        nameLabel.text = friend.name
        
        if friend.status == 0 {
            statusButton.setTitle("邀請中", for: .normal)
            statusButton.isEnabled = false
        } else if friend.status == 1 {
            statusButton.setTitle("···", for: .normal)
            statusButton.isEnabled = true
        }
    }
}

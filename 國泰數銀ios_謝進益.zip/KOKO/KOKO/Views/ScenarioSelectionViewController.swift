//
//  ScenarioSelectionViewController.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/30.
//

import UIKit

// MARK: - Class Definition
class ScenarioSelectionViewController: UIViewController {
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "選擇情境"
        navigationItem.hidesBackButton = true
    }
    
    // MARK: - Actions
    @IBAction func didTapNoFriendsScenarioButton(_ sender: UIButton) {
        pushMainTabBar(with: .noFriends)
    }
    
    @IBAction func didTapFriendsOnlyScenarioButton(_ sender: UIButton) {
        pushMainTabBar(with: .friendsOnly)
    }
    
    @IBAction func didTapFriendsWithInvitationsScenarioButton(_ sender: UIButton) {
        pushMainTabBar(with: .friendsWithInvitations)
    }
    
    // MARK: - Navigation
    private func pushMainTabBar(with initialScenario: Scenario) {
        let tabBarController = UITabBarController()
        let tabConfigs: [(
            title: String,
            imageName: String,
            imageSize: CGSize,
            viewControllerClass: UIViewController.Type,
            nibName: String?
        )] = [
            ("錢錢", "icTabbarProductsOff", CGSize(width: 28, height: 46), UIViewController.self, nil),
            ("朋友", "icTabbarFriendsOn", CGSize(width: 28, height: 46), FriendsListViewController.self, "FriendsListViewController"),
            ("KOKO", "icTabbarHomeOff", CGSize(width: 85, height: 68), UIViewController.self, nil),
            ("記帳", "icTabbarManageOff", CGSize(width: 28, height: 46), UIViewController.self, nil),
            ("設定", "icTabbarSettingOff", CGSize(width: 28, height: 46), UIViewController.self, nil)
        ]
        
        var viewControllers: [UIViewController] = []
        
        for (index, config) in tabConfigs.enumerated() {
            let vc: UIViewController
            
            if let nibName = config.nibName {
                vc = config.viewControllerClass.init(nibName: nibName, bundle: nil)
            } else {
                vc = config.viewControllerClass.init()
            }
            
            if let friendsListVC = vc as? FriendsListViewController {
                friendsListVC.viewModel = FriendsListViewModel()
                friendsListVC.setCurrentScenario(initialScenario)
                friendsListVC.viewModel?.loadData(scenario: initialScenario)
            }
            
            let image = UIImage(named: config.imageName)?.resized(to: config.imageSize)
            vc.title = config.title
            
            vc.tabBarItem = UITabBarItem(title: nil, image: image?.withRenderingMode(.alwaysOriginal), tag: index)
            
            viewControllers.append(vc)
        }
        
        tabBarController.viewControllers = viewControllers
        tabBarController.selectedIndex = 1
        
        tabBarController.navigationItem.hidesBackButton = true
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
        self.navigationController?.interactivePopGestureRecognizer?.delegate = nil
        self.navigationController?.pushViewController(tabBarController, animated: true)
    }
}

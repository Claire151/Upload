//
//  InvitationCell.swift
//  KOKO
//
//  Created by Kirk Hsieh on 2025/7/30.
//

import UIKit

// MARK: - Class Definition
class InvitationCell: UITableViewCell {

    // MARK: - IBOutlets
    @IBOutlet weak var cardBackgroundView: UIView!
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var agreeButton: UIButton!
    @IBOutlet weak var declineButton: UIButton!
    
    // MARK: - Lifecycle
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.backgroundColor = .clear
        self.contentView.backgroundColor = .clear
        
        avatarImageView.layer.cornerRadius = avatarImageView.frame.width / 2
        avatarImageView.clipsToBounds = true

        cardBackgroundView.layer.cornerRadius = 6
        cardBackgroundView.layer.masksToBounds = false
        cardBackgroundView.backgroundColor = .white

        cardBackgroundView.layer.shadowColor = UIColor.black.cgColor
        cardBackgroundView.layer.shadowOpacity = 0.15
        cardBackgroundView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardBackgroundView.layer.shadowRadius = 4

        cardBackgroundView.layer.shouldRasterize = true
        cardBackgroundView.layer.rasterizationScale = UIScreen.main.scale

        agreeButton.addTarget(self, action: #selector(agreeButtonTapped), for: .touchUpInside)
        declineButton.addTarget(self, action: #selector(declineButtonTapped), for: .touchUpInside)
    }

    // MARK: - Actions
    @objc private func agreeButtonTapped() {
        // TODO: 處理同意好友邀請動作
    }

    @objc private func declineButtonTapped() {
        // TODO: 處理拒絕好友邀請意動作
    }

    // MARK: - Configuration
    func configure(with invitation: Friend) {
        nameLabel.text = invitation.name 
    }
}

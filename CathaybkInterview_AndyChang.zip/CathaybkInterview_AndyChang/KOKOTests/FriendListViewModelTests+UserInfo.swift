//
//  FriendListViewModelTests.swift
//  KOKOTests
//
//  Created by Andy Chang on 2025/8/4.
//

import XCTest
@testable import KOKO

final class FriendListViewModelTests: XCTestCase {

    func testLoadUserInfo_withEmptyInfo_displayDefaultValues() async {
        let (sut, loader) = makeSUT()
        loader.userInfo = UserInfo(name: "", kokoId: "")
        do {
            try await sut.loadUserInfo()
            
            XCTAssertEqual(sut.displayUserName, "")
            XCTAssertEqual(sut.displayKokoId, FriendFeatureViewModel.KokoIdPrompt.empty)
            XCTAssertFalse(sut.isRedDotHidden)
        } catch {
            XCTFail("Failed to load user info with error: \(error)")
        }
    }
    
    func testLoadUserInfo_withValidInfo_displayCorrectValues() async {
        let (sut, loader) = makeSUT()
        loader.userInfo = UserInfo(name: "John Doe", kokoId: "12345")
        
        do {
            try await sut.loadUserInfo()
            
            XCTAssertEqual(sut.displayUserName, "John Doe")
            XCTAssertEqual(sut.displayKokoId, FriendFeatureViewModel.KokoIdPrompt.filled + "12345")
            XCTAssertTrue(sut.isRedDotHidden)
        } catch {
            XCTFail("Failed to load user info with error: \(error)")
        }
    }
    
    func testLoadUserInfo_withEmptyKokoId_showRedDot() async {
        let (sut, loader) = makeSUT()
        loader.userInfo = UserInfo(name: "John Doe", kokoId: "")
        
        do {
            try await sut.loadUserInfo()
            
            XCTAssertEqual(sut.displayUserName, "John Doe")
            XCTAssertEqual(sut.displayKokoId, FriendFeatureViewModel.KokoIdPrompt.empty)
            XCTAssertFalse(sut.isRedDotHidden)
        } catch {
            XCTFail("Failed to load user info with error: \(error)")
        }
    }
    
    func testLoadUserInfo_withValidKokoId_hideRedDot() async {
        let (sut, loader) = makeSUT()
        loader.userInfo = UserInfo(name: "John Doe", kokoId: "12345")
        
        do {
            try await sut.loadUserInfo()
            
            XCTAssertEqual(sut.displayUserName, "John Doe")
            XCTAssertEqual(sut.displayKokoId, FriendFeatureViewModel.KokoIdPrompt.filled + "12345")
            XCTAssertTrue(sut.isRedDotHidden)
        } catch {
            XCTFail("Failed to load user info with error: \(error)")
        }
    }

    private func makeSUT() -> (FriendFeatureViewModel, MockUserInfoLoader) {
        let loader = MockUserInfoLoader()
        let viewModel = FriendFeatureViewModel(userInfoLoader: loader, friendListLoader: MockFriendListLoader())
        trackForMemoryLeaks(loader)
        trackForMemoryLeaks(viewModel)
        return (viewModel, loader)
    }
}

final class MockUserInfoLoader: UserInfoLoader {
    var userInfo = UserInfo(name: "", kokoId: "")
    
    func load() async throws -> UserInfo {
        return userInfo
    }
}

final class MockFriendListLoader: FriendListLoader {
    func loadFriendList() async throws -> [Friend] {
        return []
    }
}
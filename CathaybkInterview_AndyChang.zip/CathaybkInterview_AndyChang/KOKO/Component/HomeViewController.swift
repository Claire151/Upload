//
//  HomeViewController.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/6.
//

import UIKit

protocol HomeViewControllerDelegate: AnyObject {
    func segmentDidChange(_ segment: Int)
}

class HomeViewController: UIViewController {
    
    @IBOutlet weak var segment: UISegmentedControl!
    weak var delegate: HomeViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func segmentValueChanged(_ sender: UISegmentedControl) {
        delegate?.segmentDidChange(sender.selectedSegmentIndex)
    }
}

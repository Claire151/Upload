import UIKit

class MainTabBarController: UITabBarController {

    private let centerButton = UIButton(type: .custom)
    private let separatorView = UIView()
    private var friendFeatureNav: UINavigationController = UINavigationController()
    private let senario1Loaders = [
        RemoteFriendListLoader(url: URL(string: "https://dimanyen.github.io/friend4.json")!)
    ]
    private let senario2Loaders = [
        RemoteFriendListLoader(url: URL(string: "https://dimanyen.github.io/friend1.json")!),
        RemoteFriendListLoader(url: URL(string: "https://dimanyen.github.io/friend2.json")!)
    ]
    private let senario3Loaders = [
        RemoteFriendListLoader(url: URL(string: "https://dimanyen.github.io/friend3.json")!)
    ]

    override func viewDidLoad() {
        super.viewDidLoad()

        setupViewControllers()
        setupSeparatorView()
        setupCenterButton()
        
        // 將中間 TabBarItem 的內容留空
        if let items = tabBar.items, items.count > 2 {
            items[2].isEnabled = false
        }
        
        centerButtonTapped()
    }

    private func setupViewControllers() {
        let moneyVC = UIViewController()
        moneyVC.view.backgroundColor = .white
        let moneyNav = UINavigationController(rootViewController: moneyVC)
        moneyNav.tabBarItem = UITabBarItem(title: nil, image: UIImage(resource: .icTabbarProducts).withRenderingMode(.alwaysOriginal), selectedImage: UIImage(resource: .icTabbarProducts).withRenderingMode(.alwaysOriginal))
        moneyNav.tabBarItem.imageInsets = UIEdgeInsets(top: 14, left: 0, bottom: -14, right: 0)

        let friendVC = createFriendFeatureViewController(loaders: senario1Loaders)
        friendFeatureNav = UINavigationController(rootViewController: friendVC)
        friendFeatureNav.tabBarItem = UITabBarItem(title: nil, image: UIImage(resource: .icTabbarFriends).withRenderingMode(.alwaysOriginal), selectedImage: UIImage(resource: .icTabbarFriends).withRenderingMode(.alwaysOriginal))
        friendFeatureNav.tabBarItem.imageInsets = UIEdgeInsets(top: 14, left: 0, bottom: -14, right: 0)

        let homeVC = HomeViewController(nibName: String(describing: HomeViewController.self), bundle: Bundle(for: HomeViewController.self))
        homeVC.delegate = self
        
        let accountingVC = UIViewController()
        accountingVC.view.backgroundColor = .white
        let accountingNav = UINavigationController(rootViewController: accountingVC)
        accountingNav.tabBarItem = UITabBarItem(title: nil, image: UIImage(resource: .icTabbarManage).withRenderingMode(.alwaysOriginal), selectedImage: UIImage(resource: .icTabbarManage).withRenderingMode(.alwaysOriginal))
        accountingNav.tabBarItem.imageInsets = UIEdgeInsets(top: 14, left: 0, bottom: -14, right: 0)

        let settingsVC = UIViewController()
        settingsVC.view.backgroundColor = .white
        let settingsNav = UINavigationController(rootViewController: settingsVC)
        settingsNav.tabBarItem = UITabBarItem(title: nil, image: UIImage(resource: .icTabbarSetting).withRenderingMode(.alwaysOriginal), selectedImage: UIImage(resource: .icTabbarSetting).withRenderingMode(.alwaysOriginal))
        settingsNav.tabBarItem.imageInsets = UIEdgeInsets(top: 14, left: 0, bottom: -14, right: 0)
        
        viewControllers = [moneyNav, friendFeatureNav, homeVC, accountingNav, settingsNav]
    }

    private func setupCenterButton() {
        centerButton.setImage(UIImage(resource: .icTabbarHome), for: .normal)
        
        centerButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(centerButton)
        
        NSLayoutConstraint.activate([
            centerButton.centerXAnchor.constraint(equalTo: tabBar.centerXAnchor),
            centerButton.topAnchor.constraint(equalTo: tabBar.topAnchor, constant: -14),
            centerButton.widthAnchor.constraint(equalToConstant: 85),
            centerButton.heightAnchor.constraint(equalToConstant: 68)
        ])
        
        centerButton.addTarget(self, action: #selector(centerButtonTapped), for: .touchUpInside)
    }

    private func setupSeparatorView() {
        separatorView.backgroundColor = UIColor(red: 228/255.0, green: 228/255.0, blue: 228/255.0, alpha: 1)
        separatorView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(separatorView)
        
        NSLayoutConstraint.activate([
            separatorView.leadingAnchor.constraint(equalTo: tabBar.leadingAnchor),
            separatorView.trailingAnchor.constraint(equalTo: tabBar.trailingAnchor),
            separatorView.bottomAnchor.constraint(equalTo: tabBar.topAnchor),
            separatorView.heightAnchor.constraint(equalToConstant: 1)
        ])
    }

    @objc private func centerButtonTapped() {
        // 當中間按鈕被點擊時，切換到第三個 tab
        self.selectedIndex = 2
    }
    
    private func createFriendFeatureViewController(loaders: [FriendListLoader]) -> UIViewController {
        let userLoader = RemoteUserInfoLoader()
        
        let friendLoader = ComposedFriendListLoader(loaders: loaders)
        let viewModel = FriendFeatureViewModel(userInfoLoader: userLoader, friendListLoader: friendLoader)
        return FriendFeatureViewController(viewModel: viewModel)
    }
}

extension MainTabBarController: HomeViewControllerDelegate {
    func segmentDidChange(_ segment: Int) {
        var loaders = [FriendListLoader]()
        switch segment {
        case 0:
            loaders = senario1Loaders
        case 1:
            loaders = senario2Loaders
        case 2:
            loaders = senario3Loaders
        default:
            break
        }
        let friendVC = createFriendFeatureViewController(loaders: loaders)
        friendFeatureNav.setViewControllers([friendVC], animated: true)
    }
}

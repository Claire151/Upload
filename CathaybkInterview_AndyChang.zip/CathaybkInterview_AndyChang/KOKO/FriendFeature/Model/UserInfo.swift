//
//  UserInfo.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/5.
//

import Foundation

struct UserInfo: Codable {
    let name: String
    let kokoId: String
    
    enum CodingKeys: String, CodingKey {
        case name
        case kokoId = "kokoid"
    }
}

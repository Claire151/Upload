//
//  APIResponse.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/5.
//

import Foundation

struct APIResponse<T: Codable>: Codable {
    let response: [T]
}

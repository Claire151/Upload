//
//  FriendListResponse.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/5.
//

import Foundation

struct Friend: Codable {
    let name: String
    let status: FriendStatus
    let isTop: Bool
    let fid: String
    let updateDate: Date
    
    enum CodingKeys: String, CodingKey {
        case name
        case status
        case isTop
        case fid
        case updateDate
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        name = try container.decode(String.self, forKey: .name)
        status = try container.decode(FriendStatus.self, forKey: .status)
        let isTopStringValue = try container.decode(String.self, forKey: .isTop)
        isTop = isTopStringValue == "1"
        fid = try container.decode(String.self, forKey: .fid)
        let dateString = try container.decode(String.self, forKey: .updateDate)
        updateDate = try Self.dateFromString(dateString)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(name, forKey: .name)
        try container.encode(status, forKey: .status)
        try container.encode(isTop, forKey: .isTop)
        try container.encode(fid, forKey: .fid)
        try container.encode(updateDate, forKey: .updateDate)
    }
    
    private static func dateFromString(_ dateString: String) throws -> Date {
        let formatter = DateFormatter()
        
        let formats = ["yyyyMMdd", "yyyy/MM/dd"]
        
        for format in formats {
            formatter.dateFormat = format
            if let date = formatter.date(from: dateString) {
                return date
            }
        }
        
        throw DecodingError.dataCorrupted(
            DecodingError.Context(
                codingPath: [CodingKeys.updateDate],
                debugDescription: "Cannot parse date string: \(dateString)"
            )
        )
    }
    
    private static func stringFromDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        return formatter.string(from: date)
    }
}

enum FriendStatus: Int, Codable {
    case inviting = 0
    case completed = 1
    case requestAddFriend = 2
}

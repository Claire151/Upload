//
//  UserInfoLoader.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/4.
//

import Foundation

protocol UserInfoLoader {
    func load() async throws -> UserInfo
}

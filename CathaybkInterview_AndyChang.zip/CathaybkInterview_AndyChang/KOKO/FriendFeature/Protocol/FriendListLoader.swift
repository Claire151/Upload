//
//  FriendListLoader.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/5.
//

import Foundation

protocol FriendListLoader {
    func loadFriendList() async throws -> [Friend]
}

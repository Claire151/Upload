//
//  BeingInvitedListViewModel.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/6.
//

import Foundation
import Combine
import UIKit

class FriendRequestListViewModel {
    @Published var allCellViewModels = [FriendRequestCellViewModel]()
    @Published var displayCellViewModels = [FriendRequestCellViewModel]()
    @Published var isExpanded: Bool = false
    @Published var isHidden: Bool = false
    
    var collapsedLayoutFrames: [CGRect] = []
    var expandedLayoutFrames: [CGRect] = []
    
    var requestList: [Friend] = [] {
        didSet {
            allCellViewModels = FriendRequestCellViewModel.createCellViewModel(for: requestList)
            displayCellViewModels = Array(allCellViewModels.prefix(2))
            isHidden = allCellViewModels.count == 0
            
            updateLayoutFrames()
        }
    }
    
    func toggleExpandState() {
        isExpanded.toggle()
        updateLayoutFrames()
    }
    
    private func updateLayoutFrames() {
        let screenWidth = UIScreen.main.bounds.width
        
        collapsedLayoutFrames = []
        let itemCount = min(2, displayCellViewModels.count)
        for i in 0..<itemCount {
            let frame: CGRect
            if i == 0 {
                frame = CGRect(x: 0, y: CGFloat(i) * 10.0, width: screenWidth, height: 80)
            } else {
                let reducedWidth = screenWidth - 20
                let xOffset = (screenWidth - reducedWidth) / 2
                frame = CGRect(x: xOffset, y: CGFloat(i) * 10.0, width: reducedWidth, height: 80)
            }
            collapsedLayoutFrames.append(frame)
        }
        
        expandedLayoutFrames = []
        for i in 0..<allCellViewModels.count {
            let frame = CGRect(x: 0, y: CGFloat(i) * 81, width: screenWidth, height: 80) // 80高度 + 1間距
            expandedLayoutFrames.append(frame)
        }
    }
}

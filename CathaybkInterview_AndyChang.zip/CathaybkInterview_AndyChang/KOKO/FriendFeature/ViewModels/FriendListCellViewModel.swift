//
//  FriendListCellViewModel.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/6.
//

import Foundation
import Combine

class FriendListCellViewModel {
    let fid: String
    let name: String
    let isTop: Bool
    let status: FriendStatus
    let moreIsHidden: Bool
    let invitingIsHidden: Bool
    init(friend: Friend) {
        fid = friend.fid
        name = friend.name
        isTop = friend.isTop
        status = friend.status
        switch status {
        case .inviting:
            moreIsHidden = true
            invitingIsHidden = false
        case .completed:
            moreIsHidden = false
            invitingIsHidden = true
        case .requestAddFriend:
            moreIsHidden = true
            invitingIsHidden = false
        }
    }
    
    class func createCellViewModel(for friends: [Friend]) -> [FriendListCellViewModel] {
        return friends.map{ FriendListCellViewModel(friend: $0) }
    }
}

//
//  FriendListViewModel.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/6.
//

import Foundation
import Combine

class FriendListViewModel {
    @Published var allCellViewModels = [FriendListCellViewModel]()
    @Published var filteredCellViewModels = [FriendListCellViewModel]()
    @Published var shouldDismissKeyboard = false
    
    var friendList: [Friend] = [] {
        didSet {
            allCellViewModels = FriendListCellViewModel.createCellViewModel(for: friendList).sorted { first, second in
                // 首先檢查 status 是否為 .inviting
                if first.status == .inviting && second.status != .inviting {
                    return true
                } else if first.status != .inviting && second.status == .inviting {
                    return false
                }
                
                // 如果 status 都是 .inviting 或都不是，則檢查 isTop
                if first.isTop && !second.isTop {
                    return true
                } else if !first.isTop && second.isTop {
                    return false
                }
                
                // 如果 isTop 相同，則按 fid 排序
                return first.fid < second.fid
            }

            filteredCellViewModels = filterCellViewModel(by: searchText)
        }
    }
    
    var searchText: String = "" {
        didSet {
            filteredCellViewModels = filterCellViewModel(by: searchText)
        }
    }
    
    private func filterCellViewModel(by searchText: String) -> [FriendListCellViewModel] {
        guard searchText.isEmpty == false else {
            return allCellViewModels
        }
        return allCellViewModels.filter {
            $0.name.lowercased().contains(searchText.lowercased())
        }
    }
    
    func dismissKeyboard() {
        shouldDismissKeyboard = true
    }
    
    func resetKeyboardDismissState() {
        shouldDismissKeyboard = false
    }
}
//
//  FriendRequestCellViewModel.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/6.
//

import Foundation

class FriendRequestCellViewModel: Hashable {
    let fid: String
    let name: String
    let message: String = "邀請你成為好友 :)"
    
    init(friend: Friend) {
        fid = friend.fid
        name = friend.name
    }
    
    static func createCellViewModel(for friends: [Friend]) -> [FriendRequestCellViewModel] {
        return friends.map{ FriendRequestCellViewModel(friend: $0) }
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(fid)
    }
    
    static func == (lhs: FriendRequestCellViewModel, rhs: FriendRequestCellViewModel) -> Bool {
        lhs.fid == rhs.fid
    }
}

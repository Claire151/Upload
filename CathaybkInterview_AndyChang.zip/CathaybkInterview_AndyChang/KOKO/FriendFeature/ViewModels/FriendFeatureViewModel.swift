//
//  FriendListViewModel.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/4.
//

import Foundation
import Combine

class FriendFeatureViewModel {
    let userInfoLoader: UserInfoLoader
    let friendListLoader: FriendListLoader
    let friendListViewModel: FriendListViewModel
    let friendRequestListViewModel: FriendRequestListViewModel
    let navigationViewModel: FriendFeatureNavigationViewModel
    
    struct KokoIdPrompt {
        static let empty = "設定 KOKO ID"
        static let filled = "KOKO ID： "
    }
    
    @Published var displayUserName: String = ""
    @Published var displayKokoId: String = KokoIdPrompt.empty
    @Published var isRedDotHidden: Bool = false
    
    init(userInfoLoader: UserInfoLoader, friendListLoader: FriendListLoader) {
        self.userInfoLoader = userInfoLoader
        self.friendListLoader = friendListLoader
        self.friendListViewModel = FriendListViewModel()
        self.friendRequestListViewModel = FriendRequestListViewModel()
        self.navigationViewModel = FriendFeatureNavigationViewModel()
    }
    
    func loadUserInfo() async throws {
        do {
            let userInfo = try await userInfoLoader.load()
            displayUserName = userInfo.name
            displayKokoId = userInfo.kokoId.isEmpty ? KokoIdPrompt.empty : KokoIdPrompt.filled + userInfo.kokoId
            isRedDotHidden = !userInfo.kokoId.isEmpty
        } catch {
            throw error
        }
    }
    
    func loadFriendList() async throws {
        do {
            let friends = try await friendListLoader.loadFriendList()
            
            //重複fid時僅保留updateDate最新的一筆
            let uniqueFriends = friends.reduce(into: [String: Friend]()) { result, friend in
                if let existing = result[friend.fid] {
                    if friend.updateDate > existing.updateDate {
                        result[friend.fid] = friend
                    }
                } else {
                    result[friend.fid] = friend
                }
            }
            
            let allFriends = Array(uniqueFriends.values)
            let (regularFriends, requestFriends) = allFriends.reduce(into: ([Friend](), [Friend]())) { result, friend in
                if friend.status == .requestAddFriend {
                    result.1.append(friend)
                } else {
                    result.0.append(friend)
                }
            }
            
            friendListViewModel.friendList = regularFriends.sorted(by: { $0.fid < $1.fid })
            
            friendRequestListViewModel.requestList = requestFriends.sorted(by: { $0.fid < $1.fid })
            
        } catch {
            throw error
        }
    }
}
//
//  FriendFeatureNavigationViewModel.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/4.
//

import Foundation
import Combine

class FriendFeatureNavigationViewModel: ObservableObject {
    enum Page: Int, CaseIterable {
        case friends = 0
        case chats = 1
    }
    
    @Published var currentPage: Page = .friends
    @Published var isFriendRequestViewHidden: Bool = true
    @Published var friendRequestViewHeight: CGFloat = 130
    
    func setCurrentPage(_ page: Page) {
        currentPage = page
    }
    
    func setCurrentPageToNext() {
        switch currentPage {
        case .friends:
            currentPage = .chats
        case .chats:
            currentPage = .friends
        }
    }
    
    func updateFriendRequestViewState(count: Int, isExpanded: Bool) {
        isFriendRequestViewHidden = count == 0
        friendRequestViewHeight = isExpanded ? 200 : 130
    }
}

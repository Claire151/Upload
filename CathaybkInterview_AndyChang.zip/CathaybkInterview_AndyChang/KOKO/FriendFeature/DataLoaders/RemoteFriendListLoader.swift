//
//  RemoteFriendListLoader.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/5.
//

import Foundation

struct RemoteFriendListLoader: FriendListLoader {
    let url: URL
    let session = URLSession(configuration: .default)
    
    init(url: URL) {
        self.url = url
    }
    
    func loadFriendList() async throws -> [Friend] {
        do {
            let (data, _) = try await session.data(from: url)
            let listResponse = try JSONDecoder().decode(APIResponse<Friend>.self, from: data)
            return listResponse.response
        } catch {
            throw error
        }
    }
}

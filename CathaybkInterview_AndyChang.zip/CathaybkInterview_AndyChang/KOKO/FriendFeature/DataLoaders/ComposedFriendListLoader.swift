//
//  ComposedFriendListLoader.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/5.
//

import Foundation

struct ComposedFriendListLoader: FriendListLoader {
    let loaders: [FriendListLoader]
    
    init(loaders: [FriendListLoader]) {
        self.loaders = loaders
    }
    
    func loadFriendList() async throws -> [Friend] {
        let tasks = loaders.map { loader in
            Task {
                try await loader.loadFriendList()
            }
        }
        
        var allFriends: [Friend] = []
        
        for task in tasks {
            let friends = try await task.value
            allFriends.append(contentsOf: friends)
        }
        
        return allFriends
    }
}

//
//  RemoteUserInfoLoader.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/5.
//

import Foundation

struct RemoteUserInfoLoader: UserInfoLoader {
    let url = URL(string: "https://dimanyen.github.io/man.json")!
    let session = URLSession(configuration: .default)
    func load() async throws -> UserInfo {
        do {
            let (data, _) = try await session.data(from: url)
            let infoResponse = try JSONDecoder().decode(APIResponse<UserInfo>.self, from: data)
            return infoResponse.response.first ?? UserInfo(name: "", kokoId: "")
        } catch {
            throw error
        }
    }
}

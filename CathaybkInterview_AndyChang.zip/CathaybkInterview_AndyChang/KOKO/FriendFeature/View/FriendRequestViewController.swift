//
//  FriendRequestViewController.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/6.
//

import UIKit
import Combine

class FriendRequestViewController: UIViewController {

    enum Section {
        case main
    }

    private var collectionView: UICollectionView!
    private var dataSource: UICollectionViewDiffableDataSource<Section, FriendRequestCellViewModel>!
    private var viewModel: FriendRequestListViewModel
    private var cancellables = Set<AnyCancellable>()

    private var isExpanded = false {
        didSet {
            updateLayoutAndSnapshot()
        }
    }

    init(viewModel: FriendRequestListViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        setupCollectionView()
        configureDataSource()
        bindViewModel()
    }

    private func setupCollectionView() {
        // 使用初始的收合佈局創建 CollectionView
        collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: createLayout())
        collectionView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        collectionView.backgroundColor = .clear
        collectionView.delegate = self
        collectionView.isScrollEnabled = false
        view.addSubview(collectionView)

        collectionView.register(FriendRequestCell.self, forCellWithReuseIdentifier: FriendRequestCell.reuseIdentifier)
    }

    private func bindViewModel() {
        viewModel.$allCellViewModels
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.updateLayoutAndSnapshot(animated: false)
            }
            .store(in: &cancellables)
        
        viewModel.$isExpanded
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isExpanded in
                self?.isExpanded = isExpanded
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Compositional Layout Creation

    private func createLayout() -> UICollectionViewLayout {
        let layout = UICollectionViewCompositionalLayout { [weak self] (sectionIndex, layoutEnvironment) -> NSCollectionLayoutSection? in
            guard let self = self else { return nil }
            return self.isExpanded ? self.createExpandedSection() : self.createCollapsedSection()
        }
        // 註冊背景 decoration view
        layout.register(SectionBackgroundDecorationView.self, forDecorationViewOfKind: SectionBackgroundDecorationView.elementKind)
        return layout
    }
    
    private func createCollapsedSection() -> NSCollectionLayoutSection {
        let group = NSCollectionLayoutGroup.custom(layoutSize: NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .absolute(90))) { environment in
            let containerWidth = environment.container.contentSize.width
            let itemCount = min(2, self.viewModel.displayCellViewModels.count)
            var items: [NSCollectionLayoutGroupCustomItem] = []
            
            // 使用 ViewModel 提供的佈局限制
            for i in 0..<itemCount {
                let frame: CGRect
                if i < self.viewModel.collapsedLayoutFrames.count {
                    frame = self.viewModel.collapsedLayoutFrames[i]
                } else {
                    // 預設 values
                    frame = CGRect(x: 0, y: CGFloat(i) * 10.0, width: containerWidth, height: 80)
                }
                let customItem = NSCollectionLayoutGroupCustomItem(frame: frame, zIndex: itemCount - i)
                items.append(customItem)
            }
            return items
        }
        
        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = NSDirectionalEdgeInsets(top: 30, leading: 0, bottom: 20, trailing: 0)
        
        let sectionBackground = NSCollectionLayoutDecorationItem.background(elementKind: SectionBackgroundDecorationView.elementKind)
        section.decorationItems = [sectionBackground]
        
        return section
    }

    private func createExpandedSection() -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .absolute(80))
        let group = NSCollectionLayoutGroup.vertical(layoutSize: groupSize, subitems: [item])
        
        let section = NSCollectionLayoutSection(group: group)
        section.interGroupSpacing = 1
        section.contentInsets = NSDirectionalEdgeInsets(top: 20, leading: 0, bottom: 20, trailing: 0)
        
        let sectionBackground = NSCollectionLayoutDecorationItem.background(elementKind: SectionBackgroundDecorationView.elementKind)
        sectionBackground.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)
        section.decorationItems = [sectionBackground]
        
        return section
    }

    // MARK: - Data Source

    private func configureDataSource() {
        dataSource = UICollectionViewDiffableDataSource<Section, FriendRequestCellViewModel>(collectionView: collectionView) {
            (collectionView: UICollectionView, indexPath: IndexPath, viewModel: FriendRequestCellViewModel) -> UICollectionViewCell? in
            
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: FriendRequestCell.reuseIdentifier, for: indexPath) as? FriendRequestCell else {
                fatalError("Cannot create new cell")
            }
            cell.configure(with: viewModel)
            
            cell.onAccept = { [weak self] in
                self?.handleAccept(for: viewModel, at: indexPath)
            }
            
            cell.onDecline = { [weak self] in
                self?.handleDecline(for: viewModel, at: indexPath)
            }
            
            return cell
        }
    }

    private func updateLayoutAndSnapshot(animated: Bool = true) {
        let newLayout = createLayout()
        collectionView.setCollectionViewLayout(newLayout, animated: animated)
        
        var snapshot = NSDiffableDataSourceSnapshot<Section, FriendRequestCellViewModel>()
        snapshot.appendSections([.main])
        
        let items = isExpanded ? viewModel.allCellViewModels : viewModel.displayCellViewModels
        snapshot.appendItems(items, toSection: .main)
        
        dataSource.apply(snapshot, animatingDifferences: animated)
    }
    
    private func handleAccept(for viewModel: FriendRequestCellViewModel, at indexPath: IndexPath) {
        // 處理接受好友請求的邏輯
        
    }
    
    private func handleDecline(for viewModel: FriendRequestCellViewModel, at indexPath: IndexPath) {
        // 處理拒絕好友請求的邏輯
        
    }
}

// MARK: - UICollectionViewDelegate
extension FriendRequestViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard viewModel.allCellViewModels.count >= 2 else { return }
        viewModel.toggleExpandState()
    }
    
    func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        if let _ = collectionView.cellForItem(at: indexPath) as? FriendRequestCell {
            return true
        }
        return true
    }
}

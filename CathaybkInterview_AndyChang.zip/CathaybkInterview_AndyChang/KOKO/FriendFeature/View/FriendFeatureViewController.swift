//
//  FriendListViewController.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/4.
//

import UIKit
import Combine

class FriendFeatureViewController: UIViewController {
    let viewModel: FriendFeatureViewModel
    private var subscriptions: Set<AnyCancellable> = []
    
    @IBOutlet weak var lbUserName: UILabel!
    @IBOutlet weak var lbKokoId: UILabel!
    @IBOutlet weak var viewRedDot: UIView!
    @IBOutlet weak var containerView: UIView!
    
    @IBOutlet weak var btnFriend: UIButton!
    @IBOutlet weak var btnChat: UIButton!
    @IBOutlet weak var lbFriendBadge: UILabel!
    @IBOutlet weak var lbChatBadge: UILabel!
    @IBOutlet weak var viewIndicator: UIView!
    @IBOutlet weak var cnIndicatorCenterX: NSLayoutConstraint!
    @IBOutlet weak var friendRequestContainerView: UIView!
    @IBOutlet weak var cnFriendRequestContainerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var gapView: UIView!
    
    lazy var pageViewController: UIPageViewController = {
        let pageVC = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal)
        pageVC.setViewControllers([embededViewControllers[0]], direction: .forward, animated: false)
        pageVC.dataSource = self
        pageVC.delegate = self
        return pageVC
    }()
    
    lazy var embededViewControllers: [UIViewController] = {
        var viewControllers = [UIViewController]()
        let friendListVC = FriendListViewController(viewModel: viewModel.friendListViewModel)
        viewControllers.append(friendListVC)
        let chatListVC = ChatListViewController(nibName: String(describing: ChatListViewController.self), bundle: Bundle(for: ChatListViewController.self))
        viewControllers.append(chatListVC)
        return viewControllers
    }()
    
    lazy var friendRequestVC: FriendRequestViewController = {
        return FriendRequestViewController(viewModel: viewModel.friendRequestListViewModel)
    }()
    
    init(viewModel: FriendFeatureViewModel) {
        self.viewModel = viewModel
        super.init(nibName: String(describing: FriendFeatureViewController.self),
                   bundle: Bundle(for: FriendFeatureViewController.self))
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        bindViewModel()
        Task {
            async let userInfoTask: () = loadUserInfo()
            async let friendListTask: () = loadFriendList()
            
            await userInfoTask
            await friendListTask
        }
        setupTapGesture()
    }
    
    private func setupUI() {
        setupRightBarButtonItem()
        setupLeftBarButtonItems()
        configurePageView()
        configureBadges()
        configureFriendRequestView()
    }
    
    private func setupTapGesture() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)
    }
    
    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    private func setupRightBarButtonItem() {
        let rightButton = UIButton(type: .system)
        rightButton.setImage(UIImage(resource: .icNavPinkScan).withRenderingMode(.alwaysOriginal), for: .normal)
        rightButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 8)
        
        let rightBarButtonItem = UIBarButtonItem(customView: rightButton)
        navigationItem.rightBarButtonItem = rightBarButtonItem
    }
    
    private func setupLeftBarButtonItems() {
        let withDrawButton = UIButton(type: .system)
        withDrawButton.setImage(UIImage(resource: .icNavPinkWithdraw).withRenderingMode(.alwaysOriginal), for: .normal)
        withDrawButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 8, bottom: 0, right: 0)
        let withDrawButtonItem = UIBarButtonItem(customView: withDrawButton)
        
        let transferButton = UIButton(type: .system)
        transferButton.setImage(UIImage(resource: .icNavPinkTransfer).withRenderingMode(.alwaysOriginal), for: .normal)
        transferButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 0)
        let transferButtonItem = UIBarButtonItem(customView: transferButton)
        
        navigationItem.leftBarButtonItems = [withDrawButtonItem, transferButtonItem]
    }
    
    private func configurePageView() {
        pageViewController.isDoubleSided = false
        addChild(pageViewController)
        pageViewController.view.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(pageViewController.view)
        NSLayoutConstraint.activate([
            pageViewController.view.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 0.0),
            pageViewController.view.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: 0.0),
            pageViewController.view.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 0.0),
            pageViewController.view.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: 0.0)
        ])
    }
    
    private func configureBadges() {
        lbChatBadge.layer.cornerRadius = 9.0
        lbChatBadge.layer.masksToBounds = true
        lbFriendBadge.layer.cornerRadius = 9.0
        lbFriendBadge.layer.masksToBounds = true
    }
    
    private func configureFriendRequestView() {
        addChild(friendRequestVC)
        friendRequestVC.view.translatesAutoresizingMaskIntoConstraints = false
        friendRequestContainerView.addSubview(friendRequestVC.view)
        NSLayoutConstraint.activate([
            friendRequestVC.view.topAnchor.constraint(equalTo: friendRequestContainerView.topAnchor, constant: 0.0),
            friendRequestVC.view.bottomAnchor.constraint(equalTo: friendRequestContainerView.bottomAnchor, constant: 0.0),
            friendRequestVC.view.leadingAnchor.constraint(equalTo: friendRequestContainerView.leadingAnchor, constant: 0.0),
            friendRequestVC.view.trailingAnchor.constraint(equalTo: friendRequestContainerView.trailingAnchor, constant: 0.0)
        ])
        setupFriendRequestTapGesture()
    }
    
    private func setupFriendRequestTapGesture() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        tapGesture.cancelsTouchesInView = false
        friendRequestVC.view.addGestureRecognizer(tapGesture)
    }
    
    private func updateFriendBadge(count: Int) {
        lbFriendBadge.text = "\(count)"
        lbFriendBadge.isHidden = count == 0
    }

    private func bindViewModel() {
        viewModel.$displayUserName
            .receive(on: DispatchQueue.main)
            .sink { [weak self] displayName in
                self?.lbUserName.text = displayName
            }.store(in: &subscriptions)
        
        viewModel.$displayKokoId
            .receive(on: DispatchQueue.main)
            .sink { [weak self] displayKokoId in
                self?.lbKokoId.text = displayKokoId
            }.store(in: &subscriptions)
        
        viewModel.$isRedDotHidden
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isHidden in
                self?.viewRedDot.isHidden = isHidden
            }.store(in: &subscriptions)
        
        viewModel.friendRequestListViewModel.$allCellViewModels
            .receive(on: DispatchQueue.main)
            .sink { [weak self] viewModels in
                self?.updateFriendBadge(count: viewModels.count)
                self?.updateFriendRequestViewVisibility()
            }.store(in: &subscriptions)
        
        viewModel.friendRequestListViewModel.$isExpanded
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isExpanded in
                self?.updateFriendRequestContainerHeight(isExpanded: isExpanded)
            }.store(in: &subscriptions)
        
        viewModel.navigationViewModel.$isFriendRequestViewHidden
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isHidden in
                self?.friendRequestContainerView.isHidden = isHidden
                self?.gapView.isHidden = !isHidden
            }.store(in: &subscriptions)
        
        viewModel.navigationViewModel.$friendRequestViewHeight
            .receive(on: DispatchQueue.main)
            .sink { [weak self] height in
                self?.cnFriendRequestContainerViewHeight.constant = height
                UIView.animate(withDuration: 0.2) {
                    self?.view.layoutIfNeeded()
                }
            }.store(in: &subscriptions)
        
        viewModel.navigationViewModel.$currentPage
            .receive(on: DispatchQueue.main)
            .sink { [weak self] currentPage in
                self?.updateIndicatorConstraint(for: currentPage)
            }.store(in: &subscriptions)
    }
    
    private func updateFriendRequestViewVisibility() {
        let count = viewModel.friendRequestListViewModel.allCellViewModels.count
        viewModel.navigationViewModel.updateFriendRequestViewState(
            count: count,
            isExpanded: viewModel.friendRequestListViewModel.isExpanded
        )
    }
    
    private func loadUserInfo() async {
        do {
            try await viewModel.loadUserInfo()
        } catch {
            // handle error when loading user info here
        }
    }
    
    private func loadFriendList() async {
        do {
            try await viewModel.loadFriendList()
        } catch {
            // handle error when loading friend list here
        }
    }
    
    @IBAction func segmentButtonPressed(_ sender: UIButton) {
        scroll(toPage: sender.tag)
        if let page = FriendFeatureNavigationViewModel.Page(rawValue: sender.tag) {
            viewModel.navigationViewModel.setCurrentPage(page)
        }
    }
    
    private func updateIndicatorConstraint(for page: FriendFeatureNavigationViewModel.Page) {
        guard let targetButton = page == .friends ? btnFriend : btnChat else { return }
        updateIndicatorCenterXConstraint(alignTo: targetButton)
    }
    
    private func updateIndicatorCenterXConstraint(alignTo view: UIView) {
        if let existingConstraint = cnIndicatorCenterX {
            viewIndicator.superview?.removeConstraint(existingConstraint)
        }
        
        cnIndicatorCenterX = NSLayoutConstraint(
            item: viewIndicator as Any,
            attribute: .centerX,
            relatedBy: .equal,
            toItem: view,
            attribute: .centerX,
            multiplier: 1,
            constant: 0
        )
        
        viewIndicator.superview?.addConstraint(cnIndicatorCenterX)
        
        UIView.animate(withDuration: 0.2) { [weak self] in
            self?.view.layoutIfNeeded()
        }
    }
    
    private func updateFriendRequestContainerHeight(isExpanded: Bool) {
        viewModel.navigationViewModel.updateFriendRequestViewState(
            count: viewModel.friendRequestListViewModel.allCellViewModels.count,
            isExpanded: isExpanded
        )
    }
    
    func scroll(toPage index: Int) {
        guard index < embededViewControllers.count , index >= 0 else { return }
        pageViewController.setViewControllers([embededViewControllers[index]],
                                              direction: ((viewModel.navigationViewModel.currentPage.rawValue < index) ? .forward : .reverse),
                                              animated: true)
        if let page = FriendFeatureNavigationViewModel.Page(rawValue: index) {
            viewModel.navigationViewModel.setCurrentPage(page)
        }
    }
    
}

//MARK: - PageViewController Data Source
extension FriendFeatureViewController: UIPageViewControllerDataSource {
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        guard let viewControllerIndex = embededViewControllers.firstIndex(of: viewController) else { return nil }
        
        let previousIndex = viewControllerIndex - 1
        
        guard previousIndex >= 0 else { return nil }
        
        guard embededViewControllers.count > previousIndex else { return nil }
        
        return embededViewControllers[previousIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = embededViewControllers.firstIndex(of: viewController) else { return nil }
        
        let nextIndex = viewControllerIndex + 1
        
        guard nextIndex < embededViewControllers.count else { return nil }
        
        guard embededViewControllers.count > nextIndex else { return nil }
        
        return embededViewControllers[nextIndex]
    }
}

extension FriendFeatureViewController: UIPageViewControllerDelegate {
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        viewModel.navigationViewModel.setCurrentPageToNext()
    }
}

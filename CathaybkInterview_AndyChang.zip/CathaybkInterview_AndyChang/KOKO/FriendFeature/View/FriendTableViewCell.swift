//
//  FriendTableViewCell.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/6.
//

import UIKit

class FriendTableViewCell: UITableViewCell {

    @IBOutlet weak var btnTransfer: UIButton!
    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var lbInviting: UILabel!
    @IBOutlet weak var imgViewIsTop: UIImageView!
    
    @IBOutlet weak var viewMore: UIView!
    @IBOutlet weak var viewInviting: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        btnTransfer.layer.borderColor = UIColor(red: 236/255.0, green: 0, blue: 140/255.0, alpha: 1).cgColor
        btnTransfer.layer.borderWidth = 1
        btnTransfer.layer.cornerRadius = 2
        lbInviting.layer.borderColor = UIColor(red: 153/255.0, green: 153/255.0, blue: 153/255.0, alpha: 1).cgColor
        lbInviting.layer.borderWidth = 1
        lbInviting.layer.cornerRadius = 2
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(with viewModel: FriendListCellViewModel) {
        lbName.text = viewModel.name
        imgViewIsTop.isHidden = !viewModel.isTop
        viewMore.isHidden = viewModel.moreIsHidden
        viewInviting.isHidden = viewModel.invitingIsHidden
    }
}

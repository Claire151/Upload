//
//  FriendRequestCell.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/6.
//

import UIKit

class FriendRequestCell: UICollectionViewCell {
    static let reuseIdentifier = "FriendRequestCell"
    
    let avatarImageView = UIImageView()
    let nameLabel = UILabel()
    let messageLabel = UILabel()
    let acceptButton = UIButton()
    let declineButton = UIButton()
    let cardView = UIView()
    
    var onAccept: (() -> Void)?
    var onDecline: (() -> Void)?
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        contentView.backgroundColor = .clear
        
        cardView.translatesAutoresizingMaskIntoConstraints = false
        cardView.backgroundColor = .white
        cardView.layer.cornerRadius = 6
        cardView.layer.shadowColor = UIColor.black.cgColor
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 4
        cardView.layer.shadowOpacity = 0.1
        contentView.addSubview(cardView)
        
        // Avatar
        avatarImageView.translatesAutoresizingMaskIntoConstraints = false
        avatarImageView.contentMode = .scaleAspectFill
        avatarImageView.layer.cornerRadius = 25
        avatarImageView.clipsToBounds = true
        cardView.addSubview(avatarImageView)
        
        // Name
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = .systemFont(ofSize: 16, weight: .medium)
        cardView.addSubview(nameLabel)
        
        // Message
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.font = .systemFont(ofSize: 14)
        messageLabel.textColor = .gray
        cardView.addSubview(messageLabel)
        
        // Buttons
        acceptButton.translatesAutoresizingMaskIntoConstraints = false
        acceptButton.setImage(UIImage(resource: .btnFriendsAgree), for: .normal)
        acceptButton.addTarget(self, action: #selector(acceptButtonTapped), for: .touchUpInside)
                cardView.addSubview(acceptButton)

        cardView.addSubview(acceptButton)
        
        declineButton.translatesAutoresizingMaskIntoConstraints = false
        declineButton.setImage(UIImage(resource: .btnFriendsDelet), for: .normal)
        declineButton.addTarget(self, action: #selector(declineButtonTapped), for: .touchUpInside)
                cardView.addSubview(declineButton)

        cardView.addSubview(declineButton)
        
        let vStack = UIStackView(arrangedSubviews: [nameLabel, messageLabel])
        vStack.translatesAutoresizingMaskIntoConstraints = false
        vStack.axis = .vertical
        vStack.spacing = 4
        vStack.alignment = .leading
        cardView.addSubview(vStack)
        
        NSLayoutConstraint.activate([
            cardView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 4),
            cardView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 30),
            cardView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -30),
            cardView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -4),
            
            avatarImageView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 15),
            avatarImageView.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            avatarImageView.widthAnchor.constraint(equalToConstant: 40),
            avatarImageView.heightAnchor.constraint(equalToConstant: 40),
            
            vStack.leadingAnchor.constraint(equalTo: avatarImageView.trailingAnchor, constant: 15),
            vStack.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            vStack.trailingAnchor.constraint(equalTo: acceptButton.leadingAnchor, constant: -12),
            
            declineButton.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -15),
            declineButton.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            declineButton.widthAnchor.constraint(equalToConstant: 30),
            declineButton.heightAnchor.constraint(equalToConstant: 30),
            
            acceptButton.trailingAnchor.constraint(equalTo: declineButton.leadingAnchor, constant: -15),
            acceptButton.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            acceptButton.widthAnchor.constraint(equalToConstant: 30),
            acceptButton.heightAnchor.constraint(equalToConstant: 30)
        ])
    }
    
    func configure(with viewModel: FriendRequestCellViewModel) {
        nameLabel.text = viewModel.name
        messageLabel.text = viewModel.message
        avatarImageView.image = UIImage(resource: .imgFriendsList)
    }
    
    @objc private func acceptButtonTapped() {
        onAccept?()
    }
    
    @objc private func declineButtonTapped() {
        onDecline?()
    }
    
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let hitView = super.hitTest(point, with: event)
        
        if hitView == acceptButton || hitView == declineButton {
            return hitView
        }
        
        if acceptButton.isDescendant(of: hitView ?? UIView()) || declineButton.isDescendant(of: hitView ?? UIView()) {
            if acceptButton.frame.contains(point) {
                return acceptButton
            } else if declineButton.frame.contains(point) {
                return declineButton
            }
        }
        
        return hitView
    }
    
}

//
//  GradientButton.swift
//  KOKO
//
//  Created by Andy Chang on 2025/8/6.
//

import UIKit

class GradientButton: UIButton {

    private let gradientLayer = CAGradientLayer()

    // From left to right
    var gradientColors: [CGColor] = [
        UIColor(red: 86/255.0, green: 179/255.0, blue: 11/255.0, alpha: 1.0).cgColor,
        UIColor(red: 166/255.0, green: 204/255.0, blue: 66/255.0, alpha: 1.0).cgColor
    ]
    
    var shadowColor: CGColor? = UIColor(red: 121/255.0, green: 196/255.0, blue: 27/255.0, alpha: 1.0).cgColor

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        gradientLayer.colors = gradientColors
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        layer.insertSublayer(gradientLayer, at: 0)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = bounds
        gradientLayer.cornerRadius = bounds.height / 2
        
        layer.shadowColor = shadowColor
        layer.shadowOffset = CGSize(width: 0, height: 4)
        layer.shadowOpacity = 0.4
        layer.shadowRadius = 8

    }
}
